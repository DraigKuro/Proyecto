package com.tutienda.libros.api.services;

import com.tutienda.libros.api.models.Genero;
import java.util.List;

public interface GeneroService {

    List<Genero> obtenerGeneros();
}
