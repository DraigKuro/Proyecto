package com.tutienda.libros.api.services;

import com.tutienda.libros.api.models.Idioma;
import java.util.List;

public interface IdiomaService {

    List<Idioma> obtenerIdiomas();
}
