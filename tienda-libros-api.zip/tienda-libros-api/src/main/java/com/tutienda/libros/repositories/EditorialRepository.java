package com.tutienda.libros.repositories;

import com.tutienda.libros.models.Editorial;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EditorialRepository extends JpaRepository<Editorial, Integer> {
   // Buscar por nombre
    List<Editorial> findByNombreContainingIgnoreCase(String nombre);
}
