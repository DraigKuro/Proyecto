package com.tutienda.libros.services;

import com.tutienda.libros.models.Libro;

import java.util.List;
import java.util.Optional;

public interface LibroService {
    List<Libro> getAllLibros();
    Optional<Libro> getLibroById(int id);
    Libro saveLibro(Libro libro);
    Libro updateLibro(int id, Libro libro);
    void deleteLibro(int id);
    List<Libro> getLibrosOrdenadosPorTitulo();
}
