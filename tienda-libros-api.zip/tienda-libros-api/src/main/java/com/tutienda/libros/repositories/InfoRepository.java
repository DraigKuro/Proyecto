package com.tutienda.libros.repositories;

import com.tutienda.libros.models.Info;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InfoRepository extends JpaRepository<Info, Integer> {
   // Buscar por usuario
    List<Info> findByIdFkUsuarioIdUsuario(Integer idUsuario);
}
