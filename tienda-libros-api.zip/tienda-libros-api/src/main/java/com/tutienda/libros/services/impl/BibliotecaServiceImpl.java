package com.tutienda.libros.services.impl;

import com.tutienda.libros.models.Biblioteca;
import com.tutienda.libros.repositories.BibliotecaRepository;
import com.tutienda.libros.services.BibliotecaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BibliotecaServiceImpl implements BibliotecaService {

    @Autowired
    private BibliotecaRepository bibliotecaRepository;

    @Override
    public List<Biblioteca> getAllBibliotecas() {
        return bibliotecaRepository.findAll();
    }

    @Override
    public Optional<Biblioteca> getBibliotecaById(int id) {
        return bibliotecaRepository.findById(id);
    }

    @Override
    public Biblioteca saveBiblioteca(Biblioteca biblioteca) {
        return bibliotecaRepository.save(biblioteca);
    }

    @Override
    public Biblioteca updateBiblioteca(int id, Biblioteca biblioteca) {
        if (bibliotecaRepository.existsById(id)) {
            biblioteca.setIdBiblioteca(id);  // Asegura que se está actualizando la biblioteca correcta
            return bibliotecaRepository.save(biblioteca);
        }
        return null;  // O lanzar una excepción personalizada si la biblioteca no existe
    }

    @Override
    public void deleteBiblioteca(int id) {
        bibliotecaRepository.deleteById(id);
    }
}
