package com.tutienda.libros.services;

import com.tutienda.libros.models.Editorial;

import java.util.List;
import java.util.Optional;

public interface EditorialService {
    List<Editorial> getAllEditoriales();
    Optional<Editorial> getEditorialById(int id);
    Editorial saveEditorial(Editorial editorial);
    Editorial updateEditorial(int id, Editorial editorial);
    void deleteEditorial(int id);
}
