package com.tutienda.libros.repositories;

import com.tutienda.libros.models.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LibroRepository extends JpaRepository<Libro, Integer> {

    // Buscar por título con ordenación por título ascendente
    List<Libro> findByTituloContainingIgnoreCaseOrderByTituloAsc(String titulo);

    // Buscar por autor con ordenación por autor ascendente
    List<Libro> findByAutoresContainingIgnoreCaseOrderByAutoresAsc(String autor);

    // Buscar por género con ordenación por género ascendente
    List<Libro> findByGeneroContainingIgnoreCaseOrderByGeneroAsc(String genero);

    // Buscar por precio con ordenación por precio ascendente
    List<Libro> findByPrecioBetweenOrderByPrecioAsc(double minPrecio, double maxPrecio);

    // Buscar por precio con ordenación por precio descendente
    List<Libro> findByPrecioBetweenOrderByPrecioDesc(double minPrecio, double maxPrecio);

    // Buscar por fecha de publicación con ordenación por fecha descendente
    List<Libro> findByFechaPubliAfterOrderByFechaPubliDesc(java.util.Date fecha);

    // Buscar por valoración con ordenación por valoración ascendente
    List<Libro> findByValoracionOrderByValoracionAsc(String valoracion);

    // Buscar por DRM con ordenación por precio ascendente
    List<Libro> findByDrmOrderByPrecioAsc(boolean drm);
    
    // **Método utilizado en el servicio para ordenar los libros por título**
    List<Libro> findAllByOrderByTituloAsc();
}
