package com.tutienda.libros.repositories;

import com.tutienda.libros.models.LibroEdit;
import com.tutienda.libros.models.LibroEditPK;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LibroEditRepository extends JpaRepository<LibroEdit, LibroEditPK> {
   // Buscar por editorial
    List<LibroEdit> findByEditorialIdEditorial(Integer idEditorial);
    
    // Buscar por libro
    List<LibroEdit> findByLibroIdLibro(Integer idLibro);
}
