package com.tutienda.libros.repositories;

import com.tutienda.libros.models.Biblioteca;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BibliotecaRepository extends JpaRepository<Biblioteca, Integer> {
  // Buscar biblioteca por usuario
    List<Biblioteca> findByIdFkUsuarioIdUsuario(Integer idUsuario);
    
    // Buscar biblioteca por libro
    List<Biblioteca> findByIdFkLibroIdLibro(Integer idLibro);
}
