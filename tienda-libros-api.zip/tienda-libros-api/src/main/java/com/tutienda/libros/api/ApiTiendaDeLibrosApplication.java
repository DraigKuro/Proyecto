package com.tutienda.libros.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTiendaDeLibrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTiendaDeLibrosApplication.class, args);
	}

}
