package com.tutienda.libros.services.impl;

import com.tutienda.libros.models.Editorial;
import com.tutienda.libros.repositories.EditorialRepository;
import com.tutienda.libros.services.EditorialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EditorialServiceImpl implements EditorialService {

    @Autowired
    private EditorialRepository editorialRepository;

    @Override
    public List<Editorial> getAllEditoriales() {
        return editorialRepository.findAll();
    }

    @Override
    public Optional<Editorial> getEditorialById(int id) {
        return editorialRepository.findById(id);
    }

    @Override
    public Editorial saveEditorial(Editorial editorial) {
        return editorialRepository.save(editorial);
    }

    @Override
    public Editorial updateEditorial(int id, Editorial editorial) {
        if (editorialRepository.existsById(id)) {
            editorial.setIdEditorial(id);  // Asegura que se está actualizando la editorial correcta
            return editorialRepository.save(editorial);
        }
        return null;  // O lanzar una excepción personalizada si la editorial no existe
    }

    @Override
    public void deleteEditorial(int id) {
        editorialRepository.deleteById(id);
    }
}
