package com.tutienda.libros.services;

import com.tutienda.libros.models.Usuarios;

import java.util.List;
import java.util.Optional;

public interface UsuariosService {
    List<Usuarios> getAllUsuarios();
    Optional<Usuarios> getUsuarioById(int id);
    Usuarios saveUsuario(Usuarios usuario);
    Usuarios updateUsuario(int id, Usuarios usuario);
    void deleteUsuario(int id);
}
