package com.tutienda.libros.services.impl;

import com.tutienda.libros.models.Libro;
import com.tutienda.libros.repositories.LibroRepository;
import com.tutienda.libros.services.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibroServiceImpl implements LibroService {

    @Autowired
    private LibroRepository libroRepository;

    @Override
    public List<Libro> getAllLibros() {
        return libroRepository.findAll();
    }

    @Override
    public Optional<Libro> getLibroById(int id) {
        return libroRepository.findById(id);
    }

    @Override
    public Libro saveLibro(Libro libro) {
        return libroRepository.save(libro);
    }

    @Override
    public Libro updateLibro(int id, Libro libro) {
        if (libroRepository.existsById(id)) {
            libro.setIdLibro(id);  // Asegura que se está actualizando el libro correcto
            return libroRepository.save(libro);
        }
        return null;  // O lanzar una excepción personalizada si el libro no existe
    }

    @Override
    public void deleteLibro(int id) {
        libroRepository.deleteById(id);
    }

    @Override
    public List<Libro> getLibrosOrdenadosPorTitulo() {
        return libroRepository.findAllByOrderByTituloAsc();
    }
}
