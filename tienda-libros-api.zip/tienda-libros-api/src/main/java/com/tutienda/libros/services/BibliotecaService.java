package com.tutienda.libros.services;

import com.tutienda.libros.models.Biblioteca;

import java.util.List;
import java.util.Optional;

public interface BibliotecaService {
    List<Biblioteca> getAllBibliotecas();
    Optional<Biblioteca> getBibliotecaById(int id);
    Biblioteca saveBiblioteca(Biblioteca biblioteca);
    Biblioteca updateBiblioteca(int id, Biblioteca biblioteca);
    void deleteBiblioteca(int id);
}
