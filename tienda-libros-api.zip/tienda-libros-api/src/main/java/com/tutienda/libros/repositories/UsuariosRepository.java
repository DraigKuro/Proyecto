package com.tutienda.libros.repositories;

import com.tutienda.libros.models.Usuarios;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuariosRepository extends JpaRepository<Usuarios, Integer> {
      // Buscar por usuario
    Optional<Usuarios> findByUsuario(String usuario);
    
    // Buscar por correo
    Optional<Usuarios> findByCorreo(String correo);
    
    // Buscar por nombre y apellido
    List<Usuarios> findByNombreContainingIgnoreCaseAndApellidosContainingIgnoreCase(String nombre, String apellidos);
}
