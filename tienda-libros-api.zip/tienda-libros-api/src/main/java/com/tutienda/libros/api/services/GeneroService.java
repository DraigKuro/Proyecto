package com.tutienda.libros.api.services;

import com.tutienda.libros.api.models.Genero;
import java.util.List;

/**
 *
 * @author Andia Rosales Alexis damt208
 */
public interface GeneroService {

    List<Genero> obtenerGeneros();
}
