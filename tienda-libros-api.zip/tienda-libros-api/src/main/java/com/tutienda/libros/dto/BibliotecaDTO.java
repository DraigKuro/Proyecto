package com.tutienda.libros.dto;

import java.util.List;

public class BibliotecaDTO {

    private Integer idBiblioteca;
    private String nombre;
    private List<Integer> idLibros;

    // Getters y Setters
    public Integer getIdBiblioteca() {
        return idBiblioteca;
    }

    public void setIdBiblioteca(Integer idBiblioteca) {
        this.idBiblioteca = idBiblioteca;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Integer> getIdLibros() {
        return idLibros;
    }

    public void setIdLibros(List<Integer> idLibros) {
        this.idLibros = idLibros;
    }
}
